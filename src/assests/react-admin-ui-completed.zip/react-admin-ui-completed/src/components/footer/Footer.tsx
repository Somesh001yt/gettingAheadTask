import "./footer.scss"

const Footer = () => {
  return (
    <div className="footer">
      <span>lamadmin</span>
      <span>© Lama Dev Admin Dashboard</span>
    </div>
  )
}

export default Footer